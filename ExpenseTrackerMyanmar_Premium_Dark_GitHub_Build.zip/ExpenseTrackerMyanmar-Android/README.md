# Expense Tracker Myanmar - Android

Android WebView wrapper for the supplied Expense Tracker Myanmar HTML app.

## Build APK using GitHub Actions (phone-friendly)
1. Create a new GitHub repository.
2. Upload the contents of this project ZIP to the repository (keep the `.github/workflows/build-apk.yml` file).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `Expense-Tracker-Myanmar-APK`.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Notes
- App records use the browser local storage inside the app and remain on the device.
- The supplied HTML currently loads Tailwind, Lucide, Chart.js and Padauk font from CDNs, so those visual libraries need an internet connection. Transaction data itself is stored locally.
- Debug APK is for testing/sideloading. A release APK should be signed before public distribution.
